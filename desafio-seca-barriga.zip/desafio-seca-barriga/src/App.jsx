import { useState, useRef, useEffect } from "react";

const CHAPTERS = [
  { id:"welcome", title:"Boas-Vindas", icon:"🌸" },
  { id:"how", title:"Como Funciona", icon:"📋" },
  { id:"mindset", title:"Mentalidade", icon:"🧠" },
  { id:"hydration", title:"Desafio da Hidratação", icon:"💧" },
  { id:"eating", title:"Alimentação Consciente", icon:"🥗" },
  { id:"drinks", title:"Reduzir Refrigerantes", icon:"🚫" },
  { id:"fruits", title:"Frutas e Verduras", icon:"🍎" },
  { id:"walking", title:"Desafio da Caminhada", icon:"👟" },
  { id:"exercise", title:"Exercícios em Casa", icon:"🏠" },
  { id:"sleep", title:"Desafio do Sono", icon:"🌙" },
  { id:"selfesteem", title:"Desafio da Autoestima", icon:"💖" },
  { id:"discipline", title:"Desafio da Disciplina", icon:"🔥" },
  { id:"calendar", title:"Calendário 90 Dias", icon:"📅" },
  { id:"planner", title:"Planner Semanal", icon:"📝" },
  { id:"weight", title:"Controle de Peso", icon:"⚖️" },
  { id:"measures", title:"Controle de Medidas", icon:"📏" },
  { id:"notes", title:"Minhas Anotações", icon:"✏️" },
  { id:"final", title:"Mensagem Final", icon:"⭐" },
];

const PROMPTS = {
  welcome:`Escreva a seção de Boas-Vindas de um livro digital chamado "Desafio Seca Barriga 90 Dias". Escreva em português brasileiro, de forma acolhedora, como uma amiga calorosa falando com a leitora. Dê boas-vindas emocionantes, valide a coragem dela em estar aqui, fale sobre o poder da transformação e prepare-a emocionalmente para os 90 dias. Aproximadamente 3 parágrafos inspiradores. Não use markdown com asteriscos — use texto simples com parágrafos.`,
  how:`Escreva a seção "Como Funciona o Desafio" do livro "Desafio Seca Barriga 90 Dias". Explique de forma amigável como o desafio de 90 dias está estruturado, que é para iniciantes, que não precisa de academia, que é feito em casa. Tom de amiga empolgada, em português brasileiro. Aproximadamente 3 parágrafos. Texto simples sem asteriscos.`,
  mindset:`Escreva a seção "Mentalidade para Emagrecer" do livro "Desafio Seca Barriga 90 Dias". Fale sobre mentalidade positiva, acreditar em si mesma, não comparar com outras pessoas, respeitar o próprio ritmo. Inclua mensagem motivacional poderosa no final. Tom de coach feminina acolhedora, em português brasileiro. Aproximadamente 4 parágrafos. Texto simples.`,
  hydration:`Escreva a seção "Desafio da Hidratação" do livro "Desafio Seca Barriga 90 Dias". Estilo: "Nosso primeiro desafio é muito simples, mas extremamente poderoso..." Desafio de beber 2 litros de água por dia. Inclua explicação detalhada, benefícios para saúde, benefícios para emagrecimento, 3 dicas práticas e mensagem motivacional. Em português brasileiro, tom de amiga carinhosa. Texto simples sem asteriscos, aproximadamente 5 parágrafos.`,
  final:`Escreva a Mensagem Final de Transformação do livro "Desafio Seca Barriga 90 Dias". A mensagem mais emocionante do livro. Fale sobre a jornada, como a leitora mudou, continuar além dos 90 dias, transformação além do físico. Termine com frase poderosa. Em português brasileiro, tom emocionante e acolhedor. Texto simples sem asteriscos, aproximadamente 4 parágrafos.`,
};

// ── FRUITS DATA ─────────────────────────────────────────────────────────────
const WEEKLY_FRUITS = [
  { day:"Segunda-feira", color:"#fff0f0", accent:"#e05555",
    morning:{fruit:"Mamão",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Papaya.jpg/320px-Papaya.jpg",tip:"½ mamão em jejum — estimula o intestino e desincha a barriga"},
    afternoon:{fruit:"Melancia",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Watermelon_seedless_2010.jpg/320px-Watermelon_seedless_2010.jpg",tip:"1 fatia média — hidrata e mata a vontade de doce"},
    night:{fruit:"Maçã",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Red_Apple.jpg/320px-Red_Apple.jpg",tip:"1 maçã com casca — fibras que ajudam a digestão noturna"},
    veggie:"Alface, pepino e tomate" },
  { day:"Terça-feira", color:"#fff8f0", accent:"#e07a30",
    morning:{fruit:"Banana",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Banana-Chocolate-Chip-Cookies-%285099605141%29.jpg/320px-Banana-Chocolate-Chip-Cookies-%285099605141%29.jpg",tip:"1 banana com aveia — energia para o dia e sacia bem"},
    afternoon:{fruit:"Laranja",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Oranges_and_orange_juice.jpg/320px-Oranges_and_orange_juice.jpg",tip:"1 laranja descascada — vitamina C e fibras"},
    night:{fruit:"Pêra",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Pears.jpg/320px-Pears.jpg",tip:"1 pêra — suave e ajuda no sono tranquilo"},
    veggie:"Brócolis, cenoura e beterraba" },
  { day:"Quarta-feira", color:"#f0fff4", accent:"#3a9a5c",
    morning:{fruit:"Abacaxi",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Pineapple_and_cross_section.jpg/320px-Pineapple_and_cross_section.jpg",tip:"2 fatias — bromelina que seca a barriga"},
    afternoon:{fruit:"Uva",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/Table_grapes_on_white.jpg/320px-Table_grapes_on_white.jpg",tip:"1 cacho pequeno — antioxidantes e energia"},
    night:{fruit:"Kiwi",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Kiwi_-_zm%C3%A4ngt.jpg/320px-Kiwi_-_zm%C3%A4ngt.jpg",tip:"1 kiwi — melhora o sono e é rico em vitamina C"},
    veggie:"Espinafre, abobrinha e pimentão" },
  { day:"Quinta-feira", color:"#f8f0ff", accent:"#8a40cc",
    morning:{fruit:"Morango",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/PerfectStrawberry.jpg/320px-PerfectStrawberry.jpg",tip:"1 xícara — baixo em calorias e cheio de antioxidantes"},
    afternoon:{fruit:"Goiaba",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/Guava_ID.jpg/320px-Guava_ID.jpg",tip:"1 goiaba vermelha — mais vitamina C que laranja"},
    night:{fruit:"Maçã",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Red_Apple.jpg/320px-Red_Apple.jpg",tip:"1 maçã — fibras e saciedade para dormir sem fome"},
    veggie:"Couve, repolho e chuchu" },
  { day:"Sexta-feira", color:"#fffff0", accent:"#b8960a",
    morning:{fruit:"Manga",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Mango_fruit_2009_edit.jpg/320px-Mango_fruit_2009_edit.jpg",tip:"½ manga — vitaminas A e C, energia tropical"},
    afternoon:{fruit:"Melão",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Musk_melon_2.jpg/320px-Musk_melon_2.jpg",tip:"2 fatias — super hidratante e levíssimo"},
    night:{fruit:"Pêssego",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Autumn_Red_peaches.jpg/320px-Autumn_Red_peaches.jpg",tip:"1 pêssego — pouco calórico e ajuda o descanso"},
    veggie:"Agrião, rúcula e vagem" },
  { day:"Sábado", color:"#f0f8ff", accent:"#2a7abf",
    morning:{fruit:"Abacate",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/c/c6/Avocado_Hass_-_single_and_halved.jpg/320px-Avocado_Hass_-_single_and_halved.jpg",tip:"¼ abacate com limão — gordura boa que sacia e nutre"},
    afternoon:{fruit:"Caju",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Caju_-_Cajueiro.jpg/320px-Caju_-_Cajueiro.jpg",tip:"1 caju fresco — rico em vitamina C"},
    night:{fruit:"Banana",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Banana-Chocolate-Chip-Cookies-%285099605141%29.jpg/320px-Banana-Chocolate-Chip-Cookies-%285099605141%29.jpg",tip:"1 banana — triptofano que ajuda a relaxar e dormir"},
    veggie:"Cenoura crua, milho cozido e ervilha" },
  { day:"Domingo", color:"#fff0f8", accent:"#cc4488",
    morning:{fruit:"Framboesa",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Ripe_Raspberries_in_the_Sun.jpg/320px-Ripe_Raspberries_in_the_Sun.jpg",tip:"½ xícara — antioxidantes poderosos com iogurte"},
    afternoon:{fruit:"Tangerina",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/The_mandarin_orange.jpg/320px-The_mandarin_orange.jpg",tip:"2 tangerinas — refrescante e cheia de vitaminas"},
    night:{fruit:"Maçã ou Pêra",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Red_Apple.jpg/320px-Red_Apple.jpg",tip:"Feche a semana com leveza — a escolha é sua!"},
    veggie:"Salada colorida livre: misture suas preferidas" },
];

const HEALTHY_FOODS = [
  { category:"☀️ Café da Manhã", color:"#fff8e6", accent:"#e6990a", items:[
    {name:"Aveia com frutas",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Oatmeal-instantoatmeal.jpg/320px-Oatmeal-instantoatmeal.jpg",tip:"Aveia em flocos com banana e mel — sacia por horas"},
    {name:"Ovo cozido",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg/320px-Good_Food_Display_-_NCI_Visuals_Online.jpg",tip:"2 ovos — proteína completa que evita a fome"},
    {name:"Iogurte natural",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Curd_-_The_Perfect_Indian_Grocery.jpg/320px-Curd_-_The_Perfect_Indian_Grocery.jpg",tip:"Iogurte sem açúcar com granola — probióticos"},
    {name:"Tapioca integral",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Tapioca_1.jpg/320px-Tapioca_1.jpg",tip:"Tapioca com queijo branco — leve e sem glúten"}]},
  { category:"🍽️ Almoço Ideal", color:"#f0fff4", accent:"#2e8b57", items:[
    {name:"Frango grelhado",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg/320px-Good_Food_Display_-_NCI_Visuals_Online.jpg",tip:"100-150g — proteína magra que preserva músculo"},
    {name:"Arroz integral + feijão",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Feij%C3%A3o-com-arroz.jpg/320px-Feij%C3%A3o-com-arroz.jpg",tip:"A dupla perfeita — proteína completa e fibras"},
    {name:"Salada colorida",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Garden_salad_%28cropped%29.jpg/320px-Garden_salad_%28cropped%29.jpg",tip:"Quanto mais colorida, mais vitaminas!"},
    {name:"Peixe assado",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/FriedFish.jpg/320px-FriedFish.jpg",tip:"Ômega-3 que reduz inflamação e queima gordura"}]},
  { category:"🌤️ Lanche da Tarde", color:"#fff0f8", accent:"#cc4488", items:[
    {name:"Castanhas e nozes",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Mixed_nuts.jpg/320px-Mixed_nuts.jpg",tip:"Um punhado — gorduras boas que saciam"},
    {name:"Fruta com iogurte",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Curd_-_The_Perfect_Indian_Grocery.jpg/320px-Curd_-_The_Perfect_Indian_Grocery.jpg",tip:"1 fruta com iogurte natural — doce e nutritivo"},
    {name:"Cenoura e pepino",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Vegetable_garden%2C_almost_all_harvested.jpg/320px-Vegetable_garden%2C_almost_all_harvested.jpg",tip:"Em palitinhos com homus — crocante e levinho"},
    {name:"Vitamina verde",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Curd_-_The_Perfect_Indian_Grocery.jpg/320px-Curd_-_The_Perfect_Indian_Grocery.jpg",tip:"Couve + banana + limão + água de coco — desinflama"}]},
  { category:"🌙 Jantar Leve", color:"#f0f4ff", accent:"#4455cc", items:[
    {name:"Sopa de legumes",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Potato_soup.jpg/320px-Potato_soup.jpg",tip:"Abóbora, cenoura e abobrinha — leve e reconfortante"},
    {name:"Omelete de verduras",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg/320px-Good_Food_Display_-_NCI_Visuals_Online.jpg",tip:"Com espinafre, tomate e queijo — rápido e proteico"},
    {name:"Frango com legumes",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg/320px-Good_Food_Display_-_NCI_Visuals_Online.jpg",tip:"Frango desfiado com brócolis no vapor — jantar ideal"},
    {name:"Salada com atum",img:"https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Garden_salad_%28cropped%29.jpg/320px-Garden_salad_%28cropped%29.jpg",tip:"Folhas + atum + tomate + azeite — anti-inflamatório"}]},
];

// ── CONFETTI ────────────────────────────────────────────────────────────────
function Confetti({ active }) {
  if (!active) return null;
  const pieces = Array.from({length:70},(_,i)=>({
    id:i, left:Math.random()*100, delay:Math.random()*1.2,
    color:["#c8756c","#f4a460","#6abf85","#7eb8e8","#e8a8cc","#f7d06a","#a06abf","#ff6b9d","#ffd93d"][i%9],
    size:7+Math.random()*9, rotate:Math.random()*360,
    shape:i%3
  }));
  return (
    <div style={{position:"fixed",top:0,left:0,width:"100%",height:"100%",pointerEvents:"none",zIndex:9999,overflow:"hidden"}}>
      <style>{`@keyframes fall{0%{transform:translateY(-20px) rotate(0deg);opacity:1}100%{transform:translateY(105vh) rotate(720deg);opacity:0}}`}</style>
      {pieces.map(p=>(
        <div key={p.id} style={{position:"absolute",left:`${p.left}%`,top:0,width:p.size,height:p.size,background:p.color,
          borderRadius:p.shape===0?"50%":p.shape===1?"2px":"50% 0 50% 0",
          animation:`fall ${1.8+p.delay}s ${p.delay}s ease-in forwards`,transform:`rotate(${p.rotate}deg)`}}/>
      ))}
    </div>
  );
}

// ── BADGE ───────────────────────────────────────────────────────────────────
function CompletedBadge({message}) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:12,background:"linear-gradient(135deg,#3a9a5c,#6abf85)",borderRadius:16,padding:"16px 22px",marginTop:16,color:"white",boxShadow:"0 4px 20px #6abf8540"}}>
      <span style={{fontSize:36}}>✅</span>
      <div>
        <div style={{fontWeight:800,fontSize:17}}>🎉 Desafio Concluído!</div>
        <div style={{fontSize:13.5,opacity:0.92,marginTop:2}}>{message||"Parabéns! Você é incrível! Continue assim! 🌸"}</div>
      </div>
    </div>
  );
}

// ── YES/NO CHALLENGE ────────────────────────────────────────────────────────
function YesNoChallenge({challenges, accentColor="#c8756c"}) {
  const [answers, setAnswers] = useState({});
  const [confettiIdx, setConfettiIdx] = useState(null);
  const allDone = challenges.every((_,i)=>answers[i]===true);

  const handleYes = (i) => {
    if (answers[i]===true) return;
    setAnswers(prev=>{const n={...prev,[i]:true}; return n;});
    setConfettiIdx(i);
    setTimeout(()=>setConfettiIdx(null), 3200);
  };

  return (
    <div>
      <Confetti active={confettiIdx!==null}/>
      {challenges.map((ch,i)=>(
        <div key={i} style={{background:answers[i]===true?"#f0fff4":answers[i]===false?"#fff5f5":"white",
          border:`2px solid ${answers[i]===true?"#6abf85":answers[i]===false?"#f0a0a0":"#f0e0de"}`,
          borderRadius:16,padding:"16px 20px",marginBottom:14,transition:"all 0.3s"}}>
          <div style={{display:"flex",alignItems:"flex-start",gap:12,marginBottom:8}}>
            <span style={{fontSize:22,marginTop:2}}>{answers[i]===true?"✅":"🎯"}</span>
            <div>
              <div style={{fontWeight:700,color:"#3d2b2b",fontSize:15,marginBottom:4}}>{ch.label}</div>
              <div style={{fontSize:13.5,color:"#6a4a4a",lineHeight:1.6}}>{ch.desc}</div>
            </div>
          </div>
          {answers[i]===true ? (
            <div style={{background:"#e8fff2",borderRadius:10,padding:"10px 14px",marginTop:8,display:"flex",alignItems:"center",gap:8}}>
              <span style={{fontSize:20}}>🌟</span>
              <span style={{color:"#2e7a50",fontWeight:700,fontSize:14}}>Arrasou! Mais um passo na sua transformação!</span>
            </div>
          ) : (
            <div style={{display:"flex",gap:10,marginTop:10,flexWrap:"wrap"}}>
              <button onClick={()=>handleYes(i)} style={{padding:"9px 22px",borderRadius:20,border:"2px solid #6abf85",background:"#6abf85",color:"white",fontWeight:700,cursor:"pointer",fontSize:13.5,fontFamily:"inherit",transition:"all 0.2s"}}>
                ✅ Sim, cumpri!
              </button>
              <button onClick={()=>setAnswers(prev=>({...prev,[i]:false}))} style={{padding:"9px 22px",borderRadius:20,border:`2px solid ${answers[i]===false?"#e08080":"#d0d0d0"}`,background:answers[i]===false?"#f08080":"white",color:answers[i]===false?"white":"#888",fontWeight:700,cursor:"pointer",fontSize:13.5,fontFamily:"inherit",transition:"all 0.2s"}}>
                ❌ Ainda não
              </button>
            </div>
          )}
          {answers[i]===false&&ch.tip&&(
            <div style={{marginTop:10,background:"#fff8e0",borderRadius:10,padding:"10px 14px",fontSize:13,color:"#7a5a00",border:"1px solid #f0d060",lineHeight:1.6}}>
              💡 <strong>Dica para conseguir:</strong> {ch.tip}
            </div>
          )}
        </div>
      ))}
      {allDone&&<CompletedBadge message="Você completou todos os desafios desta seção! Você é uma guerreira! 💪🌸"/>}
    </div>
  );
}

// ── AI QUIZ ─────────────────────────────────────────────────────────────────
function AIQuiz({questions, promptBuilder, title, subtitle, color, accent}) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const allAnswered = questions.every((_,i)=>answers[i]!==undefined);

  const handleSubmit = async () => {
    setLoading(true); setSubmitted(true);
    const summary = questions.map((q,i)=>`${q.text}: ${q.options[answers[i]]}`).join(" | ");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-6",max_tokens:1000,messages:[{role:"user",content:promptBuilder(summary)}]}),
      });
      const data = await res.json();
      setResult(data.content?.map(b=>b.text||"").join("\n")||"");
    } catch { setResult("Não foi possível gerar a análise. Tente novamente."); }
    setLoading(false);
  };

  return (
    <div>
      <div style={{background:`linear-gradient(135deg,${accent},${accent}bb)`,borderRadius:16,padding:"18px 22px",marginBottom:22,color:"white"}}>
        <div style={{fontSize:20,fontWeight:800,marginBottom:5}}>{title}</div>
        <div style={{fontSize:13.5,opacity:0.92}}>{subtitle||"Responda as perguntas e receba uma análise personalizada feita só para você! 🌸"}</div>
      </div>
      {!submitted ? (
        <>
          {questions.map((q,i)=>(
            <div key={i} style={{background:"white",borderRadius:14,padding:"16px 18px",marginBottom:14,border:"1.5px solid #f0e0de",boxShadow:"0 2px 8px #00000008"}}>
              <div style={{fontWeight:700,color:"#3d2b2b",marginBottom:12,fontSize:14.5}}>
                <span style={{color:accent,marginRight:8,fontSize:16}}>{i+1}.</span>{q.text}
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {q.options.map((opt,j)=>(
                  <button key={j} onClick={()=>setAnswers({...answers,[i]:j})}
                    style={{padding:"10px 16px",borderRadius:10,border:"2px solid",textAlign:"left",cursor:"pointer",fontFamily:"inherit",fontSize:13.5,transition:"all 0.2s",
                      borderColor:answers[i]===j?accent:"#e8c8c0",
                      background:answers[i]===j?`${accent}18`:"white",
                      color:answers[i]===j?accent:"#5a3a3a",
                      fontWeight:answers[i]===j?700:400}}>
                    {answers[i]===j?"● ":"○ "}{opt}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <button onClick={handleSubmit} disabled={!allAnswered}
            style={{width:"100%",padding:"14px",background:allAnswered?accent:"#ccc",color:"white",border:"none",borderRadius:12,fontSize:15,fontWeight:800,cursor:allAnswered?"pointer":"default",fontFamily:"inherit",marginTop:8,transition:"all 0.3s",boxShadow:allAnswered?`0 4px 16px ${accent}55`:"none"}}>
            {allAnswered?"✨ Ver Minha Análise Personalizada":"Responda todas as perguntas para continuar ⬆️"}
          </button>
        </>
      ) : (
        <div>
          <div style={{background:color,borderRadius:14,padding:"16px 20px",border:`2px solid ${accent}33`,marginBottom:16}}>
            <div style={{fontWeight:800,color:accent,marginBottom:10,fontSize:15}}>📋 Suas Respostas:</div>
            {questions.map((q,i)=>(
              <div key={i} style={{fontSize:13,color:"#5a3a3a",marginBottom:6,display:"flex",gap:8}}>
                <span style={{color:accent,fontWeight:700,minWidth:16}}>{i+1}.</span>
                <span><strong>{q.text}:</strong> {q.options[answers[i]]}</span>
              </div>
            ))}
          </div>
          {loading ? (
            <div style={{display:"flex",gap:6,alignItems:"center",padding:"24px 0"}}>
              {[0,1,2].map(i=><div key={i} style={{width:10,height:10,borderRadius:"50%",background:accent,animation:`bounce 1s ${i*0.2}s infinite`}}/>)}
              <style>{`@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}`}</style>
              <span style={{marginLeft:10,color:"#8a6a6a",fontSize:14}}>Gerando sua análise personalizada com carinho... 💫</span>
            </div>
          ) : (
            <div style={{background:"white",borderRadius:14,padding:"22px 24px",border:`2px solid ${accent}33`,boxShadow:`0 4px 20px ${accent}22`}}>
              <div style={{fontWeight:800,color:accent,marginBottom:14,fontSize:16}}>✨ Sua Análise Personalizada:</div>
              {result.split("\n").filter(Boolean).map((p,i)=><p key={i} style={{fontSize:14.5,color:"#3d2b2b",lineHeight:1.85,marginBottom:14}}>{p}</p>)}
            </div>
          )}
          <button onClick={()=>{setSubmitted(false);setAnswers({});setResult("");}}
            style={{marginTop:14,padding:"10px 22px",background:"white",border:`2px solid ${accent}`,borderRadius:10,color:accent,fontWeight:700,cursor:"pointer",fontFamily:"inherit",fontSize:13}}>
            🔄 Refazer Quiz
          </button>
        </div>
      )}
    </div>
  );
}

// ── SLEEP ────────────────────────────────────────────────────────────────────
function SleepSection() {
  return <AIQuiz
    title="🌙 Quiz do Sono — Como estão suas noites?"
    subtitle="Descubra como seus hábitos de sono estão afetando seu corpo e emagrecimento. Responda com honestidade!"
    color="#f0f0ff" accent="#6655cc"
    questions={[
      {text:"Quantas horas você dorme por noite?", options:["Menos de 5 horas","Entre 5 e 6 horas","Entre 6 e 7 horas","7 a 8 horas ou mais"]},
      {text:"Como você se sente ao acordar?", options:["Muito cansada, difícil levantar","Cansada mas consigo","Razoavelmente disposta","Descansada e animada"]},
      {text:"Você usa celular ou TV antes de dormir?", options:["Sempre, até pegar no sono","Quase sempre","Às vezes","Raramente ou nunca"]},
      {text:"Você acorda no meio da noite?", options:["Sim, várias vezes","Sim, uma ou duas vezes","Raramente","Não, durmo direto"]},
      {text:"Você tem horário fixo para dormir?", options:["Não, dorme a horas diferentes todo dia","Às vezes tenho horário","Quase sempre no mesmo horário","Sim, durmo sempre no mesmo horário"]},
      {text:"O cansaço te faz comer mais besteira?", options:["Muito! Quando cansada como mal","Um pouco","Raramente","Não percebo diferença"]},
      {text:"Você toma café ou energético à tarde/noite?", options:["Sim, todo dia","Frequentemente","Às vezes","Não costumo"]},
    ]}
    promptBuilder={s=>`Você é especialista em saúde feminina e sono. Uma mulher respondeu um quiz sobre hábitos de sono: ${s}. Analise em português brasileiro, de forma acolhedora como amiga. Explique o que esses hábitos de sono estão causando no corpo e emagrecimento dela. Dê 5 dicas práticas e específicas baseadas nas respostas para melhorar o sono e consequentemente secar a barriga. Seja motivadora e use linguagem simples. Texto simples sem asteriscos, aproximadamente 5 parágrafos.`}
  />;
}

// ── DRINKS ───────────────────────────────────────────────────────────────────
function DrinksSection() {
  return <AIQuiz
    title="🚫 Quiz dos Refrigerantes — Qual é o seu nível?"
    subtitle="Vamos entender sua relação com as bebidas açucaradas para montar um plano personalizado para você!"
    color="#fff0f0" accent="#cc3333"
    questions={[
      {text:"Quantos refrigerantes você bebe por dia?", options:["3 ou mais por dia","1 a 2 por dia","Alguns por semana","Raramente ou nunca"]},
      {text:"O que você bebe quando está com sede?", options:["Refrigerante ou suco de caixinha","Suco natural ou achocolatado","Água com gás ou isotônico","Água pura"]},
      {text:"Você sente dificuldade de largar o refrigerante?", options:["Sim, é um vício mesmo","Um pouco difícil","Consigo controlar","Não tenho vontade"]},
      {text:"Você sente inchaço ou gases com frequência?", options:["Sempre, todo dia","Bastante frequentemente","Às vezes","Raramente"]},
      {text:"O que te faz tomar refrigerante?", options:["Vontade de algo doce","Hábito nas refeições","Companhia ou eventos sociais","Não costumo tomar"]},
      {text:"Você já tentou parar o refrigerante antes?", options:["Nunca tentei","Tentei e não consegui","Consegui por pouco tempo","Sim, já fiquei sem por meses"]},
      {text:"Você sabe quantas calorias tem uma latinha?", options:["Não faço ideia","Sei que tem muitas mas não sei o número","Sei que tem umas 150 cal","Sim, sei exatamente e me preocupo"]},
    ]}
    promptBuilder={s=>`Você é nutricionista especialista em emagrecimento feminino. Uma mulher respondeu sobre consumo de refrigerantes: ${s}. Analise em português brasileiro, como amiga carinhosa sem julgamento. Explique o impacto exato desses hábitos na barriga e no emagrecimento. Sugira 4 substitutos deliciosos personalizados para o perfil dela. Dê um plano de 3 semanas para reduzir gradualmente. Termine com mensagem motivacional gentil. Texto simples sem asteriscos, aproximadamente 5 parágrafos.`}
  />;
}

// ── EATING ───────────────────────────────────────────────────────────────────
function EatingSection() {
  const [activeTab, setActiveTab] = useState(0);
  const cat = HEALTHY_FOODS[activeTab];
  const [imgErrors, setImgErrors] = useState({});
  return (
    <div>
      <AIQuiz
        title="🥗 Quiz da Alimentação Consciente"
        subtitle="Descubra seus hábitos alimentares e receba dicas personalizadas para transformar sua relação com a comida!"
        color="#f0fff4" accent="#2e8b57"
        questions={[
          {text:"Como você costuma comer?", options:["Rápido, em pé ou na frente do celular","Sentada mas distraída","Com atenção mas com pressa","Tranquila, sem pressa e focada"]},
          {text:"Você mastiga bem os alimentos?", options:["Quase não mastigo, como muito rápido","Mastigo um pouco","Mastigo razoavelmente bem","Mastigo bastante, como devagar"]},
          {text:"Você come quando está estressada ou ansiosa?", options:["Sempre, é meu conforto","Com frequência","Às vezes","Raramente"]},
          {text:"Você para de comer quando está satisfeita?", options:["Não, sempre termino o prato","Às vezes como além da necessidade","Na maioria das vezes paro","Sempre paro quando me sinto satisfeita"]},
          {text:"Com que frequência você pula refeições?", options:["Todo dia pulo pelo menos uma","Frequentemente","Raramente","Nunca, faço todas as refeições"]},
          {text:"Como é sua relação com comida?", options:["Culpa e ansiedade — odeio fazer dieta","Controlada mas difícil","Busco equilíbrio, às vezes funciona","Saudável, gosto de me alimentar bem"]},
          {text:"Você planeja suas refeições com antecedência?", options:["Nunca, como o que aparecer","Raramente","Às vezes faço isso","Sim, gosto de planejar"]},
        ]}
        promptBuilder={s=>`Você é nutricionista e coach de alimentação consciente. Uma mulher respondeu sobre hábitos alimentares: ${s}. Analise em português brasileiro, com carinho e sem julgamento algum. Explique o que esses hábitos estão causando no corpo e no emagrecimento dela. Dê 5 dicas práticas e específicas para ela comer de forma mais consciente baseadas no perfil dela. Seja encorajadora e realista. Texto simples sem asteriscos, aproximadamente 5 parágrafos.`}
      />
      <div style={{marginTop:32}}>
        <div style={{fontWeight:800,fontSize:18,color:"#2e8b57",marginBottom:6}}>🍽️ Guia de Comidas Saudáveis por Horário</div>
        <p style={{fontSize:14,color:"#3d5a3d",marginBottom:16,lineHeight:1.6}}>Aqui estão opções deliciosas organizadas por horário. Clique em cada refeição para ver as sugestões com foto e dica!</p>
        <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:20}}>
          {HEALTHY_FOODS.map((c,i)=>(
            <button key={i} onClick={()=>setActiveTab(i)} style={{padding:"8px 16px",borderRadius:20,border:"2px solid",borderColor:activeTab===i?"#3a8a5c":"#b0e0c0",background:activeTab===i?"#3a8a5c":"white",color:activeTab===i?"white":"#3a8a5c",fontSize:12.5,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>
              {c.category}
            </button>
          ))}
        </div>
        <div style={{background:cat.color,borderRadius:16,padding:20,border:`2px solid ${cat.accent}22`}}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:12}}>
            {cat.items.map((item,i)=>(
              <div key={i} style={{background:"white",borderRadius:12,overflow:"hidden",border:"1.5px solid #f0e0de"}}>
                {!imgErrors[`${activeTab}-${i}`]
                  ? <img src={item.img} alt={item.name} onError={()=>setImgErrors(e=>({...e,[`${activeTab}-${i}`]:true}))} style={{width:"100%",height:100,objectFit:"cover"}}/>
                  : <div style={{width:"100%",height:100,background:"#f9f0ee",display:"flex",alignItems:"center",justifyContent:"center",fontSize:32}}>🍽️</div>}
                <div style={{padding:"10px 12px"}}>
                  <div style={{fontWeight:700,fontSize:13,color:"#2e5a3a",marginBottom:4}}>{item.name}</div>
                  <div style={{fontSize:12,color:"#4a6a4a",lineHeight:1.5}}>{item.tip}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div style={{background:"#f0fff4",borderRadius:12,padding:"16px 20px",border:"1.5px solid #b0e0c0",marginTop:20}}>
          <div style={{fontWeight:700,color:"#2e8b57",marginBottom:12,fontSize:14}}>🌿 Hábitos de Ouro para Comer com Consciência</div>
          {["Mastigue cada garfada pelo menos 20 vezes — a digestão começa na boca!","Desligue a TV e o celular enquanto come para sentir cada sabor.","Use prato menor — o cérebro entende como porção completa e satisfatória.","Espere 20 minutos antes de repetir — a saciedade demora para chegar ao cérebro.","Beba um copo de água antes de cada refeição — ajuda a controlar a fome.","Planeje as refeições da semana — quem planeja não improvisa com besteira!"].map((h,i)=>(
            <div key={i} style={{fontSize:13.5,color:"#3d5a3d",marginBottom:8,display:"flex",gap:8}}><span>✅</span><span>{h}</span></div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── WALKING ──────────────────────────────────────────────────────────────────
const WALKING_CHALLENGES = [
  {label:"🚶 Semana 1 — Caminhada de 20 minutos",desc:"Hoje você vai caminhar por 20 minutos sem parar! Pode ser dentro de casa, no quintal ou no bairro. O importante é mover o corpo e começar.",tip:"Coloque uma música animada e caminhe no ritmo dela. 20 minutos passam rápido quando você está curtindo!"},
  {label:"⏱️ Semana 2 — Caminhe 25 minutos",desc:"Aumentamos 5 minutinhos! Seu corpo já está se adaptando e agradece muito. Caminhe em ritmo confortável mas não tão lento — mantenha a respiração ativa.",tip:"Experimente caminhar de manhã cedo — o metabolismo fica acelerado o dia todo e você se sente mais disposta!"},
  {label:"⚡ Semana 3 — Caminhada intervalada",desc:"Caminhe 25 minutos alternando: 3 minutos no ritmo normal, 1 minuto mais rápido. Isso acelera o metabolismo muito mais do que a caminhada constante!",tip:"Essa técnica queima 30% mais gordura! Aumente a passada, balance os braços e respire fundo nos momentos rápidos."},
  {label:"🔥 Semana 4 — 30 minutos por dia, 5 dias",desc:"A meta dessa semana é caminhar 30 minutos por pelo menos 5 dias. Você está chegando perto da metade do desafio — não desista agora!",tip:"Se tiver dificuldade, divida em 2 caminhadas de 15 minutos — o resultado é o mesmo e cabe em qualquer rotina!"},
  {label:"🏗️ Desafio Extra — Use as escadas!",desc:"Toda vez que tiver escada disponível esta semana, use ela em vez do elevador ou escada rolante. São calorias extras queimadas sem esforço extra!",tip:"Subir escadas trabalha exatamente os músculos que ajudam a secar a barriga, o quadril e a coxa. É treino grátis!"},
  {label:"🌅 Desafio Especial — Caminhada em jejum",desc:"Uma manhã esta semana, antes do café da manhã, caminhe por 20 minutos. O corpo usa a gordura estocada como combustível e os resultados são ainda maiores!",tip:"Beba um copo de água antes de sair. Se sentir tontura ou fraqueza, pare e coma algo. Sempre respeite seu corpo!"},
];

function WalkingSection() {
  return (
    <div>
      <div style={{background:"linear-gradient(135deg,#5a8a3c,#8abf60)",borderRadius:16,padding:"20px 24px",marginBottom:8,color:"white"}}>
        <div style={{fontSize:21,fontWeight:800,marginBottom:6}}>👟 Desafios Progressivos da Caminhada</div>
        <div style={{fontSize:14,opacity:0.92,lineHeight:1.6}}>Cada desafio liberado é uma vitória. Marque <strong>Sim, cumpri!</strong> quando completar e ganhe seu selo de guerreira com confetes! 🎉</div>
      </div>
      <div style={{background:"#f0fff4",borderRadius:10,padding:"12px 16px",marginBottom:20,border:"1.5px solid #b0e0c0"}}>
        <span style={{fontSize:13,color:"#2e6a40"}}>💡 <strong>Como funciona:</strong> Complete cada desafio no ritmo que for seu. Se não conseguiu hoje, tente amanhã — o que importa é não desistir!</span>
      </div>
      <YesNoChallenge challenges={WALKING_CHALLENGES} accentColor="#5a8a3c"/>
    </div>
  );
}

// ── EXERCISE ─────────────────────────────────────────────────────────────────
const EXERCISE_CHALLENGES = [
  {label:"💪 Nível 1 — 10 Agachamentos",desc:"Faça 10 agachamentos agora! Pés na largura do quadril, desça devagar como se fosse sentar numa cadeira. Subindo, aperte o bumbum! Descanse e repita.",tip:"Se sentir dor nos joelhos, não desça tanto. Com o tempo vai ficando mais fácil e você vai querer fazer mais — promessa!"},
  {label:"🏃 Nível 1 — 30 Polichinelos",desc:"30 polichinelos — pule abrindo os braços e pernas ao mesmo tempo. Pode fazer na velocidade que quiser, do seu jeito e do seu ritmo!",tip:"Eles aceleram o coração rapidinho! São ótimos para queimar caloria sem precisar sair de casa ou ter equipamento."},
  {label:"🧱 Nível 2 — Prancha por 20 segundos",desc:"Deite de bruços, apoie nos antebraços e nas pontas dos pés. Fique 20 segundos firme como uma tábua! Respire normalmente e não prenda a respiração.",tip:"A prancha trabalha todo o core profundo e vai secar sua barriga gradualmente. Aumente o tempo a cada semana!"},
  {label:"🔥 Nível 2 — 15 Abdominais",desc:"15 abdominais! Deite, dobre os joelhos, mãos cruzadas no peito e suba o tronco levemente. Não precisa ir até o joelho — movimento pequeno e controlado.",tip:"O movimento pequeno e controlado é mais eficaz que subir muito! Sinta o abdômen contrair em cada repetição."},
  {label:"💪 Nível 3 — Flexão modificada",desc:"10 flexões com os joelhos no chão! Mãos na largura dos ombros, desça o peito em direção ao chão devagar e suba com força. Respire corretamente.",tip:"Modificada não é fraqueza — é inteligência! Constrói força real nos braços, peito e core. Aumente para 15 quando sentir confiança!"},
  {label:"🏆 TREINO COMPLETO — 20 minutos",desc:"Hora da sequência completa! Faça: 15 agachamentos + 30 polichinelos + prancha 30s + 15 abdominais + 10 flexões. Descanse 1 min e repita mais 2 vezes!",tip:"Parabéns! Esse é seu treino funcional completo em casa. Você não precisa de academia pra ser incrível — você já é!"},
];

function ExerciseSection() {
  return (
    <div>
      <div style={{background:"linear-gradient(135deg,#8b3a3a,#c8756c)",borderRadius:16,padding:"20px 24px",marginBottom:8,color:"white"}}>
        <div style={{fontSize:21,fontWeight:800,marginBottom:6}}>🏠 Desafios de Exercícios em Casa</div>
        <div style={{fontSize:14,opacity:0.92,lineHeight:1.6}}>Confirme cada exercício concluído, ganhe confetes e colecione seus selos! Você pode muito mais do que imagina! 💪</div>
      </div>
      <div style={{background:"#fff8f0",borderRadius:10,padding:"12px 16px",marginBottom:20,border:"1.5px solid #f0c8a0"}}>
        <span style={{fontSize:13,color:"#8b4a1a"}}>🔑 <strong>Dica de ouro:</strong> Não precisa fazer tudo no mesmo dia! Complete cada desafio quando se sentir pronta. O progresso é mais importante que a perfeição.</span>
      </div>
      <YesNoChallenge challenges={EXERCISE_CHALLENGES} accentColor="#c8756c"/>
    </div>
  );
}

// ── SELF-ESTEEM ───────────────────────────────────────────────────────────────
function SelfEsteemSection() {
  return <AIQuiz
    title="💖 Quiz da Autoestima & Beleza — Descubra seu potencial!"
    subtitle="Responda sobre seus hábitos de autocuidado e beleza e receba um guia completo e personalizado só para você ✨"
    color="#fff0f8" accent="#cc4488"
    questions={[
      {text:"Com que frequência você cuida da sua pele (hidratação, limpeza)?", options:["Nunca tenho essa rotina","Raramente, só quando lembro","Às vezes, sem consistência","Todo dia, tenho rotina de skincare"]},
      {text:"Você usa maquiagem ou se arruma para sair?", options:["Nunca, não sei usar e não me animo","Raramente, só em ocasiões especiais","Às vezes quando tenho tempo e disposição","Sim, gosto muito de me produzir!"]},
      {text:"Como você se sente ao olhar no espelho?", options:["Evito olhar, não gosto do que vejo","Olho mas vejo só os defeitos","Me sinto razoável, aceito na média","Me aceito com amor e vejo minha beleza"]},
      {text:"Como está seu cabelo hoje?", options:["Descuidado, não tenho rotina capilar","Faço o básico, poderia cuidar mais","Cuido mas poderia intensificar","Tenho rotina capilar consistente e me sinto bem!"]},
      {text:"Como você se veste no dia a dia?", options:["Roupas folgadas que me escondem","Roupas simples que não me representam","Roupas que gosto mas poderia ousar mais","Me visto com intenção e me sinto bonita!"]},
      {text:"Você usa acessórios (brincos, colares, pulseiras, bolsas)?", options:["Nunca, não tenho esse hábito","Raramente, em ocasiões especiais","Às vezes uso um ou dois","Sempre — adoro acessorizar e compor looks!"]},
      {text:"Você se perfuma ou cuida do seu aroma?", options:["Nunca penso nisso","Só uso perfume em ocasiões especiais","Às vezes uso","Sim, tenho perfume favorito e uso todo dia"]},
      {text:"Sua autoestima hoje está em qual nível?", options:["Muito baixa — me sinto invisível e sem valor","Baixa — tenho muitas inseguranças","Razoável — alguns dias me sinto bem","Boa — me aceito mas sempre quero evoluir"]},
    ]}
    promptBuilder={s=>`Você é especialista em beleza, autoestima e empoderamento feminino, como uma personal stylist e consultora de imagem que é melhor amiga. Uma mulher respondeu sobre seus hábitos de autocuidado e autoestima: ${s}. Escreva em português brasileiro, com MUITO carinho, entusiasmo e sem julgamento. Monte um guia personalizado completo com estas QUATRO partes claramente separadas no texto: PARTE 1 - SKINCARE: Rotina de cuidados com a pele para o perfil dela (manhã e noite), produtos acessíveis que ela pode usar (hidratante, protetor solar, sérum vitamina C, esfoliante semanal). PARTE 2 - MAQUIAGEM: Maquiagem simples mas que valoriza (base leve ou BB cream, rímel, blush, batom/gloss), passo a passo rápido para o dia a dia. PARTE 3 - LOOKS E ACESSÓRIOS: Dicas de roupas que valorizam o corpo dela e estilo de vida, como usar brincos, colares e pulseiras para compor looks, cores que ficam bem. PARTE 4 - RITUAL DIÁRIO DE AUTOESTIMA: Exercício diário de amor próprio, afirmações positivas para repetir no espelho, hábitos que aumentam a autoestima. Seja específica, empolgante e faça ela se sentir a mulher mais linda do mundo! Texto simples sem asteriscos.`}
  />;
}

// ── DISCIPLINE ────────────────────────────────────────────────────────────────
function DisciplineSection() {
  return <AIQuiz
    title="🔥 Quiz da Disciplina — Qual é o seu perfil real?"
    subtitle="Vamos descobrir seus sabotadores e criar estratégias personalizadas para você manter o foco nos 90 dias!"
    color="#fff8f0" accent="#e06a20"
    questions={[
      {text:"Quando você começa um desafio, por quanto tempo costuma manter?", options:["Menos de uma semana","1 a 2 semanas","Até 1 mês","Consigo manter por muito tempo"]},
      {text:"O que normalmente te faz desistir?", options:["Não ver resultado rápido","Estresse, ansiedade ou tristeza","Comemorações e eventos sociais","Raramente desisto"]},
      {text:"Como é sua relação com rotina e organização?", options:["Odeio rotina, sou muito impulsiva","Tenho rotina mas quase não sigo","Sigo às vezes, quando estou motivada","Adoro rotina e a sigo com consistência"]},
      {text:"Você se perdoa quando come algo fora do plano?", options:["Não, fico me culpando e desisto de tudo","Difícil perdoar, mas tento continuar","Sim, recomeço na próxima refeição","Sim, faz parte do processo saudável"]},
      {text:"Quando você falta um dia de exercício, o que acontece?", options:["Desisto de tudo pois quebrei a sequência","Fico culpada mas volto depois","Compenso com calma no dia seguinte","Retomo normalmente — é só um dia!"]},
      {text:"Qual é seu maior obstáculo para a disciplina?", options:["Falta de motivação e energia","Ansiedade e comer emocional","Falta de tempo na rotina","Influência de pessoas ao redor"]},
      {text:"Você já conseguiu criar um hábito saudável que manteve por mais de 3 meses?", options:["Nunca consegui manter nada","Consegui mas perdi depois","Sim, mas preciso de ajuda para outros","Sim, sei como criar hábitos e manter"]},
    ]}
    promptBuilder={s=>`Você é coach de comportamento, hábitos e empoderamento feminino. Uma mulher respondeu sobre seu perfil de disciplina: ${s}. Escreva em português brasileiro, com muito carinho e ZERO julgamento — ela precisa se sentir acolhida, não julgada. Analise o perfil dela, identifique os 2-3 principais sabotadores e dê um plano prático com 6 estratégias personalizadas para ela criar disciplina sustentável nos próximos 90 dias. Inclua: como lidar com os gatilhos específicos dela, o que fazer quando errar (porque vai errar e tudo bem!), como celebrar pequenas vitórias, e uma técnica de recomeço rápido. Seja motivadora, realista e poderosa. Termine com uma frase que ela vai querer tatuar na alma. Texto simples sem asteriscos, aproximadamente 6 parágrafos.`}
  />;
}

// ── FRUITS SECTION ────────────────────────────────────────────────────────────
function FruitCard({time, icon, data}) {
  const [imgError, setImgError] = useState(false);
  return (
    <div style={{background:"white",borderRadius:12,overflow:"hidden",border:"1.5px solid #f0e0de",flex:1,minWidth:170}}>
      <div style={{background:time==="Manhã"?"#fff8e0":time==="Tarde"?"#fff0e8":"#e8eeff",padding:"8px 12px",fontWeight:700,fontSize:13,color:"#5a3a3a"}}>{icon} {time}</div>
      {!imgError
        ? <img src={data.img} alt={data.fruit} onError={()=>setImgError(true)} style={{width:"100%",height:120,objectFit:"cover"}}/>
        : <div style={{width:"100%",height:120,background:"#f9f0ee",display:"flex",alignItems:"center",justifyContent:"center",fontSize:40}}>🍑</div>}
      <div style={{padding:"10px 12px"}}>
        <div style={{fontWeight:700,fontSize:14,color:"#8b3a3a",marginBottom:4}}>{data.fruit}</div>
        <div style={{fontSize:12.5,color:"#6a4a4a",lineHeight:1.5}}>{data.tip}</div>
      </div>
    </div>
  );
}

function FruitsSection() {
  const [activeDay, setActiveDay] = useState(0);
  const day = WEEKLY_FRUITS[activeDay];
  return (
    <div>
      <div style={{background:"linear-gradient(135deg,#c8756c,#e8a89e)",borderRadius:16,padding:"20px 24px",marginBottom:24,color:"white"}}>
        <div style={{fontSize:22,fontWeight:700,marginBottom:6}}>🍎 Cardápio de Frutas da Semana</div>
        <p style={{fontSize:14,opacity:0.9,margin:0}}>Cada fruta foi escolhida com carinho para ajudar a secar a barriga, desinchar e nutrir seu corpo!</p>
      </div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:24}}>
        {WEEKLY_FRUITS.map((d,i)=>(
          <button key={i} onClick={()=>setActiveDay(i)} style={{padding:"7px 14px",borderRadius:20,border:"2px solid",borderColor:activeDay===i?"#c8756c":"#e8c8c0",background:activeDay===i?"#c8756c":"white",color:activeDay===i?"white":"#c8756c",fontSize:12.5,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>
            {d.day.split("-")[0]}
          </button>
        ))}
      </div>
      <div style={{background:day.color,borderRadius:16,padding:20,border:`2px solid ${day.accent}22`,marginBottom:20}}>
        <div style={{fontWeight:800,fontSize:18,color:day.accent,marginBottom:16}}>📅 {day.day}</div>
        <div style={{display:"flex",gap:12,flexWrap:"wrap"}}>
          <FruitCard time="Manhã" icon="☀️" data={day.morning}/>
          <FruitCard time="Tarde" icon="🌤️" data={day.afternoon}/>
          <FruitCard time="Noite" icon="🌙" data={day.night}/>
        </div>
        <div style={{marginTop:16,background:"white",borderRadius:10,padding:"12px 16px",border:`1px solid ${day.accent}33`}}>
          <span style={{fontWeight:700,color:day.accent,fontSize:13}}>🥗 Verduras do dia: </span>
          <span style={{fontSize:13,color:"#5a3a3a"}}>{day.veggie}</span>
        </div>
      </div>
      <div style={{background:"#fff9f8",borderRadius:12,padding:"16px 20px",border:"1.5px solid #f0c8c0"}}>
        <div style={{fontWeight:700,color:"#c8756c",marginBottom:10,fontSize:14}}>💡 Dicas de Ouro</div>
        {["Prefira sempre as frutas inteiras ao suco — as fibras são suas aliadas!","Não pule as frutas da manhã — elas acordam seu metabolismo.","Frutas à noite? Sim! Escolha as leves como maçã, pêra ou kiwi.","Congele morangos e uvas para um lanche refrescante e saudável."].map((t,i)=>(
          <div key={i} style={{fontSize:13.5,color:"#5a3a3a",marginBottom:6,display:"flex",gap:8}}><span>🌸</span><span>{t}</span></div>
        ))}
      </div>
    </div>
  );
}

// ── CALENDAR ──────────────────────────────────────────────────────────────────
function CalendarSection() {
  const [checked, setChecked] = useState(()=>{try{return JSON.parse(localStorage.getItem("sb_calendar")||"{}");}catch{return {};}});
  const [confetti, setConfetti] = useState(false);
  const toggle = (day) => {
    const n={...checked,[day]:!checked[day]};
    setChecked(n);
    try{localStorage.setItem("sb_calendar",JSON.stringify(n));}catch{}
    if(!checked[day]){setConfetti(true);setTimeout(()=>setConfetti(false),3000);}
  };
  const days=Array.from({length:90},(_,i)=>i+1);
  const weeks=[];
  for(let i=0;i<90;i+=7)weeks.push(days.slice(i,i+7));
  const done=Object.values(checked).filter(Boolean).length;
  return (
    <div>
      <Confetti active={confetti}/>
      <p style={{color:"#3d2b2b",marginBottom:20,fontSize:15}}>Marque cada dia que você completou seus desafios. Cada check é uma vitória! 🏆</p>
      {weeks.map((week,wi)=>(
        <div key={wi} style={{display:"flex",gap:6,marginBottom:6,flexWrap:"wrap"}}>
          <span style={{width:60,fontSize:12,color:"#a07070",display:"flex",alignItems:"center"}}>Sem. {wi+1}</span>
          {week.map(day=>(
            <button key={day} onClick={()=>toggle(day)} style={{width:36,height:36,borderRadius:8,border:"2px solid",borderColor:checked[day]?"#c8756c":"#e8c8c0",background:checked[day]?"#c8756c":"white",color:checked[day]?"white":"#c8756c",fontSize:12,fontWeight:600,cursor:"pointer",transition:"all 0.2s"}}>
              {checked[day]?"✓":day}
            </button>
          ))}
        </div>
      ))}
      <p style={{marginTop:16,color:"#c8756c",fontWeight:600,fontSize:14}}>{done} de 90 dias concluídos 🌸</p>
      {done>=90&&<CompletedBadge message="90 dias completos! Você é extraordinária! 🌟"/>}
    </div>
  );
}

// ── PLANNER ───────────────────────────────────────────────────────────────────
function PlannerSection() {
  const days=["Segunda","Terça","Quarta","Quinta","Sexta","Sábado","Domingo"];
  const [plans,setPlans]=useState(()=>{try{return JSON.parse(localStorage.getItem("sb_planner")||"{}");}catch{return {};}});
  const update=(day,val)=>{const n={...plans,[day]:val};setPlans(n);try{localStorage.setItem("sb_planner",JSON.stringify(n));}catch{}};
  return (
    <div>
      <p style={{color:"#3d2b2b",marginBottom:20,fontSize:15}}>Planeje sua semana! Anote seus desafios, metas e como foi cada dia. 📝</p>
      {days.map(day=>(
        <div key={day} style={{marginBottom:16}}>
          <label style={{display:"block",fontWeight:700,color:"#c8756c",marginBottom:6,fontSize:14}}>{day}</label>
          <textarea value={plans[day]||""} onChange={e=>update(day,e.target.value)} placeholder={`Como foi sua ${day.toLowerCase()}?`}
            style={{width:"100%",minHeight:70,padding:10,borderRadius:10,border:"1.5px solid #e8c8c0",fontFamily:"inherit",fontSize:14,color:"#3d2b2b",background:"#fff9f8",resize:"vertical",boxSizing:"border-box"}}/>
        </div>
      ))}
    </div>
  );
}

// ── WEIGHT ────────────────────────────────────────────────────────────────────
function WeightSection() {
  const [entries,setEntries]=useState(()=>{try{return JSON.parse(localStorage.getItem("sb_weight")||"[]");}catch{return [];}});
  const [val,setVal]=useState(""); const [date,setDate]=useState("");
  const add=()=>{if(!val||!date)return;const n=[...entries,{date,weight:parseFloat(val)}].sort((a,b)=>a.date.localeCompare(b.date));setEntries(n);try{localStorage.setItem("sb_weight",JSON.stringify(n));}catch{};setVal("");setDate("");};
  const remove=i=>{const n=entries.filter((_,idx)=>idx!==i);setEntries(n);try{localStorage.setItem("sb_weight",JSON.stringify(n));}catch{}};
  const diff=entries.length>1?(entries[entries.length-1].weight-entries[0].weight).toFixed(1):null;
  return (
    <div>
      <p style={{color:"#3d2b2b",marginBottom:20,fontSize:15}}>Registre seu peso aqui. O que importa é a tendência ao longo do tempo! ⚖️</p>
      <div style={{display:"flex",gap:10,marginBottom:20,flexWrap:"wrap"}}>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} style={{padding:"8px 12px",borderRadius:8,border:"1.5px solid #e8c8c0",fontSize:14,color:"#3d2b2b"}}/>
        <input type="number" value={val} onChange={e=>setVal(e.target.value)} placeholder="Peso em kg" style={{padding:"8px 12px",borderRadius:8,border:"1.5px solid #e8c8c0",fontSize:14,width:120,color:"#3d2b2b"}}/>
        <button onClick={add} style={{padding:"8px 20px",background:"#c8756c",color:"white",border:"none",borderRadius:8,cursor:"pointer",fontWeight:600}}>Registrar</button>
      </div>
      {entries.length>0&&(<>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:14}}>
          <thead><tr style={{background:"#fff0ee"}}><th style={{padding:"8px 12px",textAlign:"left",color:"#c8756c"}}>Data</th><th style={{padding:"8px 12px",textAlign:"left",color:"#c8756c"}}>Peso</th><th/></tr></thead>
          <tbody>{entries.map((e,i)=>(<tr key={i} style={{borderBottom:"1px solid #f0e0de"}}><td style={{padding:"8px 12px",color:"#3d2b2b"}}>{e.date}</td><td style={{padding:"8px 12px",color:"#3d2b2b",fontWeight:600}}>{e.weight} kg</td><td><button onClick={()=>remove(i)} style={{background:"none",border:"none",cursor:"pointer",color:"#e0a0a0"}}>✕</button></td></tr>))}</tbody>
        </table>
        {diff!==null&&<p style={{marginTop:16,fontWeight:700,color:parseFloat(diff)<0?"#5a9a6f":"#c8756c",fontSize:15}}>{parseFloat(diff)<0?`🎉 Você perdeu ${Math.abs(diff)} kg desde o início! Incrível!`:`📈 Variação de +${diff} kg — continue firme, o corpo está se adaptando!`}</p>}
      </>)}
    </div>
  );
}

// ── MEASURES ──────────────────────────────────────────────────────────────────
function MeasuresSection() {
  const fields=["Cintura (cm)","Quadril (cm)","Abdômen (cm)","Busto (cm)","Coxa D (cm)","Coxa E (cm)","Braço D (cm)","Braço E (cm)"];
  const [entries,setEntries]=useState(()=>{try{return JSON.parse(localStorage.getItem("sb_measures")||"[]");}catch{return [];}});
  const [current,setCurrent]=useState({});const [date,setDate]=useState("");
  const save=()=>{if(!date)return;const n=[...entries,{date,measures:{...current}}].sort((a,b)=>a.date.localeCompare(b.date));setEntries(n);try{localStorage.setItem("sb_measures",JSON.stringify(n));}catch{};setCurrent({});setDate("");};
  return (
    <div>
      <p style={{color:"#3d2b2b",marginBottom:16,fontSize:15}}>As medidas contam uma história que a balança não conta! Registre mensalmente. 📏</p>
      <input type="date" value={date} onChange={e=>setDate(e.target.value)} style={{padding:"8px 12px",borderRadius:8,border:"1.5px solid #e8c8c0",fontSize:14,marginBottom:12,color:"#3d2b2b"}}/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
        {fields.map(f=>(<div key={f}><label style={{fontSize:12,color:"#a07070",display:"block",marginBottom:4}}>{f}</label><input type="number" value={current[f]||""} onChange={e=>setCurrent({...current,[f]:e.target.value})} placeholder="cm" style={{width:"100%",padding:"7px 10px",borderRadius:8,border:"1.5px solid #e8c8c0",fontSize:14,boxSizing:"border-box",color:"#3d2b2b"}}/></div>))}
      </div>
      <button onClick={save} style={{padding:"10px 24px",background:"#c8756c",color:"white",border:"none",borderRadius:8,cursor:"pointer",fontWeight:700}}>Salvar Medidas</button>
      {entries.length>0&&<div style={{marginTop:24}}>{entries.map((entry,i)=>(<div key={i} style={{background:"#fff9f8",borderRadius:10,padding:14,marginBottom:10,border:"1px solid #f0e0de"}}><strong style={{color:"#c8756c"}}>{entry.date}</strong><div style={{display:"flex",flexWrap:"wrap",gap:8,marginTop:8}}>{Object.entries(entry.measures).map(([k,v])=>(<span key={k} style={{fontSize:13,color:"#3d2b2b",background:"#fff0ee",padding:"3px 10px",borderRadius:20}}>{k.split(" (")[0]}: <strong>{v}</strong></span>))}</div></div>))}</div>}
    </div>
  );
}

// ── NOTES ─────────────────────────────────────────────────────────────────────
function NotesSection() {
  const [notes,setNotes]=useState(()=>{try{return localStorage.getItem("sb_notes")||"";}catch{return "";}});
  const save=val=>{setNotes(val);try{localStorage.setItem("sb_notes",val);}catch{}};
  return (
    <div>
      <p style={{color:"#3d2b2b",marginBottom:16,fontSize:15}}>Este é o seu espaço livre! Escreva conquistas, dificuldades, pensamentos, sonhos. ✏️</p>
      <textarea value={notes} onChange={e=>save(e.target.value)} placeholder="Escreva aqui seus pensamentos, sentimentos, conquistas e qualquer coisa que quiser guardar durante esses 90 dias..."
        style={{width:"100%",minHeight:300,padding:16,borderRadius:12,border:"1.5px solid #e8c8c0",fontFamily:"Georgia,serif",fontSize:15,lineHeight:1.8,color:"#3d2b2b",background:"#fff9f8",resize:"vertical",boxSizing:"border-box"}}/>
      <p style={{fontSize:12,color:"#b09090",marginTop:8}}>💾 Salvo automaticamente no seu dispositivo</p>
    </div>
  );
}

// ── AI TEXT ───────────────────────────────────────────────────────────────────
function AIText({chapterId}) {
  const [content,setContent]=useState(""); const [loading,setLoading]=useState(false); const [loaded,setLoaded]=useState(false);
  const cache=useRef({});
  useEffect(()=>{
    if(loaded||loading)return;
    if(cache.current[chapterId]){setContent(cache.current[chapterId]);setLoaded(true);return;}
    const prompt=PROMPTS[chapterId];if(!prompt)return;
    setLoading(true);
    fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-6",max_tokens:1000,messages:[{role:"user",content:prompt}]})})
      .then(r=>r.json()).then(data=>{const text=data.content?.map(b=>b.text||"").join("\n")||"";cache.current[chapterId]=text;setContent(text);setLoaded(true);setLoading(false);})
      .catch(()=>{setContent("Não foi possível carregar. Tente novamente.");setLoading(false);setLoaded(true);});
  },[chapterId,loaded,loading]);
  if(loading)return(
    <div style={{display:"flex",gap:6,alignItems:"center",padding:"24px 0"}}>
      {[0,1,2].map(i=><div key={i} style={{width:9,height:9,borderRadius:"50%",background:"#c8756c",animation:`bounce 1s ${i*0.2}s infinite`}}/>)}
      <style>{`@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}`}</style>
      <span style={{marginLeft:10,color:"#a07070",fontSize:14}}>Carregando com carinho... 🌸</span>
    </div>
  );
  return <div style={{lineHeight:1.85,color:"#3d2b2b"}}>{content.split("\n").filter(Boolean).map((p,i)=><p key={i} style={{marginBottom:18,fontSize:15.5}}>{p}</p>)}</div>;
}

// ── ROUTER ────────────────────────────────────────────────────────────────────
function ChapterContent({chapterId}) {
  const map={fruits:<FruitsSection/>,eating:<EatingSection/>,drinks:<DrinksSection/>,walking:<WalkingSection/>,exercise:<ExerciseSection/>,sleep:<SleepSection/>,selfesteem:<SelfEsteemSection/>,discipline:<DisciplineSection/>,calendar:<CalendarSection/>,planner:<PlannerSection/>,weight:<WeightSection/>,measures:<MeasuresSection/>,notes:<NotesSection/>};
  return map[chapterId]||<AIText chapterId={chapterId}/>;
}

// ── APP ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [activeChapter,setActiveChapter]=useState("welcome");
  const [sidebarOpen,setSidebarOpen]=useState(true);
  const contentRef=useRef(null);
  const chapter=CHAPTERS.find(c=>c.id===activeChapter);
  const goTo=id=>{setActiveChapter(id);if(contentRef.current)contentRef.current.scrollTop=0;if(window.innerWidth<768)setSidebarOpen(false);};

  return (
    <div style={{display:"flex",height:"100vh",fontFamily:"'Georgia',serif",background:"#fdf6f4",overflow:"hidden"}}>
      {/* Sidebar */}
      <div style={{width:sidebarOpen?272:0,minWidth:sidebarOpen?272:0,background:"linear-gradient(180deg,#8b3a3a 0%,#c8756c 60%,#e8a89e 100%)",overflowY:"auto",overflowX:"hidden",transition:"all 0.3s",display:"flex",flexDirection:"column"}}>
        <div style={{padding:"28px 20px 16px",borderBottom:"1px solid rgba(255,255,255,0.15)"}}>
          <div style={{fontSize:24,marginBottom:4}}>🌸</div>
          <div style={{color:"white",fontWeight:800,fontSize:15,lineHeight:1.3}}>Desafio Seca Barriga</div>
          <div style={{color:"rgba(255,255,255,0.75)",fontSize:12,marginTop:2}}>90 Dias de Transformação</div>
        </div>
        <div style={{padding:"10px 0",flex:1}}>
          {CHAPTERS.map(ch=>(
            <button key={ch.id} onClick={()=>goTo(ch.id)} style={{display:"flex",alignItems:"center",gap:10,width:"100%",padding:"11px 20px",border:"none",cursor:"pointer",textAlign:"left",background:activeChapter===ch.id?"rgba(255,255,255,0.18)":"transparent",borderLeft:activeChapter===ch.id?"3px solid white":"3px solid transparent",color:activeChapter===ch.id?"white":"rgba(255,255,255,0.78)",fontSize:13,fontFamily:"inherit",transition:"all 0.2s",fontWeight:activeChapter===ch.id?700:400}}>
              <span style={{fontSize:16}}>{ch.icon}</span>
              <span style={{lineHeight:1.3}}>{ch.title}</span>
            </button>
          ))}
        </div>
      </div>
      {/* Main */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <div style={{background:"white",borderBottom:"1px solid #f0e0de",padding:"14px 24px",display:"flex",alignItems:"center",gap:14,flexShrink:0,boxShadow:"0 2px 8px #00000008"}}>
          <button onClick={()=>setSidebarOpen(!sidebarOpen)} style={{background:"none",border:"none",cursor:"pointer",fontSize:22,color:"#c8756c",padding:0}}>☰</button>
          <div>
            <div style={{fontSize:18,fontWeight:700,color:"#8b3a3a"}}>{chapter?.icon} {chapter?.title}</div>
            <div style={{fontSize:12,color:"#b09090"}}>Desafio Seca Barriga 90 Dias</div>
          </div>
        </div>
        <div ref={contentRef} style={{flex:1,overflowY:"auto",padding:"32px 40px",maxWidth:780}}>
          <ChapterContent chapterId={activeChapter} key={activeChapter}/>
          <div style={{display:"flex",justifyContent:"space-between",marginTop:48,paddingTop:24,borderTop:"1px solid #f0e0de"}}>
            {CHAPTERS.findIndex(c=>c.id===activeChapter)>0&&(
              <button onClick={()=>{const idx=CHAPTERS.findIndex(c=>c.id===activeChapter);goTo(CHAPTERS[idx-1].id);}} style={{padding:"10px 20px",background:"white",border:"1.5px solid #e8c8c0",borderRadius:8,cursor:"pointer",color:"#c8756c",fontFamily:"inherit",fontWeight:600}}>← Anterior</button>
            )}
            <div style={{flex:1}}/>
            {CHAPTERS.findIndex(c=>c.id===activeChapter)<CHAPTERS.length-1&&(
              <button onClick={()=>{const idx=CHAPTERS.findIndex(c=>c.id===activeChapter);goTo(CHAPTERS[idx+1].id);}} style={{padding:"10px 20px",background:"#c8756c",border:"none",borderRadius:8,cursor:"pointer",color:"white",fontFamily:"inherit",fontWeight:600}}>Próximo →</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
